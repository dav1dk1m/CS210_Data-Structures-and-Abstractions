# Exercise Instructions:

linkedlist.cpp contains a sample implementation of a linked list.  However, there is a problem with the program if you try to delete a value that is not on the list.

Try using the debugger to find and fix the problem.  You may find the review on Linked Lists on the lab page helpful.